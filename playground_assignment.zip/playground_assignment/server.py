from flask import Flask, render_template
app = Flask(__name__)

@app.route('/play')
def first():
    return render_template("index.html", number=3,
    color = "yellow")

@app.route('/play/<int:number>')
def second(number):
    return render_template("index.html", number=
    number, color="yellow")

@app.route('/play/<int:number>/<string:color>')
def third(number, color):
    return render_template("index.html", number=number,
    color=color)

if __name__ == "__main__":
    app.run(debug=True)