from flask import render_template,redirect,session,request, flash
from flask_app import app
from flask_app.models.recipe import Recipe
from flask_app.models.user import User
from flask_app.models.skeptic import Skeptic


@app.route('/create/skeptic/',methods=['POST'])
def create_skeptic():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "users_id": session['user_id'],
        "recipes_id":request.form["skept"]
    }
    Skeptic.save(data)
    return redirect('/show/'+request.form["skept"])

@app.route('/destroy/skeptic/<int:id>')
def destroy_skeptic(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":id
    }
    Skeptic.destroy(data)
    return redirect('/dashboard')