from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Skeptic:
    db_name = 'sasquatches'
    def __init__(self,db_data):
        self.users_id = db_data['users_id']
        self.recipes_id = db_data['recipes_id']
        

    @classmethod
    def save(cls,data):
        query = "INSERT INTO skeptics (users_id, recipes_id) VALUES (%(users_id)s, %(recipes_id)s);"
        return connectToMySQL(cls.db_name).query_db(query, data)

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM skeptics;"
        results =  connectToMySQL(cls.db_name).query_db(query)
        all_skeptics = []
        for row in results:
            all_skeptics.append( cls(row) )
        return all_skeptics
    
    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM skeptics WHERE recipes_id = %(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        print(results)
        return cls( results[0] )
    
    @classmethod
    def destroy(cls,data):
        query = "DELETE FROM skeptics WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query,data)